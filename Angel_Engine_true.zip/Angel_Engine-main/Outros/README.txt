Este pacote contém o jogo Angel Engine com os arquivos corrigidos para uso com Tkinter.
- Todos os arquivos agora definem variáveis com arte ASCII (em vez de print).
- Você pode executar com: python Angel_Engine_Tkinter_Corrigido.py
