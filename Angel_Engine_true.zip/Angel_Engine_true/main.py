from tkinter import ttk
import pygame
import tkinter as tk
import os
from PIL import Image, ImageTk # Import Pillow modules

pygame.mixer.init()

script_dir = os.path.dirname(os.path.abspath(__file__))

def tocar_musica(cenario):
    pygame.mixer.music.stop()
    full_path = os.path.join(script_dir, 'Outros', musicas[cenario])
    print(f"Tentando carregar música: {full_path}")
    try:
        pygame.mixer.music.load(full_path)
        pygame.mixer.music.play(-1)
    except pygame.error as e:
        print(f"Erro ao carregar ou tocar música {full_path}: {e}")


musicas = {
    "introducao": 'Passado Misterioso [NGCtEepSTJI].mp3',
    "acordar": 'BlackWeald - Astral Chasm _ Dark Ambient Horror Soundscape [jJS-1mtZHIc].mp3',
    "terra_sagrada": 'Encontrei Algo Aqui_ [WkSbALPTcuQ].mp3'
}

click_sound = None
try:
    # VERIFIQUE ESTE NOME DO ARQUIVO
    click_sound_path = os.path.join(script_dir, 'Outros', 'click_sound.mp3')
    print(f"Tentando carregar som de clique: {click_sound_path}")
    click_sound = pygame.mixer.Sound(click_sound_path)
except Exception as e:
    print(f"Erro ao carregar som de clique: {e}")

def play_click_sound():
    if click_sound:
        click_sound.play()

try:
    from titulos.SHC import ascii_SHC
    # from Imagens.Anjo import ascii_anjo # We will replace this with a GIF
    from Imagens.Anjo2 import ascii_demon
    from Imagens.Anjo3 import ascii_Anjo3
    from Imagens.Presidente import ascii_presidente
    from titulos.Confinado import ascii_confinado
    from Imagens.Doutor import ascii_doutor
    from titulos.Esquecido import ascii_esquecido
    from titulos.Fugitivo import ascii_fugitivo
    from titulos.Trabalhador import ascii_trabalhador
    from titulos.Patria import ascii_patria
    from titulos.Terrasagrada import ascii_terra
    from titulos.Sonho import ascii_sonho
    from titulos.Transtornado import ascii_transtornado
    from titulos.Titulo import ascii_titulo
    from titulos.Euxarido import ascii_Euxarido
    from Imagens.Observadora import ascii_Observadora
    from Imagens.esquecido import ascii_Esquecido
    from Imagens.gato import ascii_Gato
    from titulos.Devorado import ascii_devorado

except ImportError as e:
    print(f"ImportError: {e}. Certifique-se de que os módulos de ASCII art estão nos diretórios corretos.")
    ascii_demon = ascii_presidente = ascii_confinado = ascii_doutor = ascii_esquecido = ""
    ascii_fugitivo = ascii_medroso = ascii_patria = ascii_terra = ascii_sonho = ascii_transtornado = ""
    ascii_titulo = ascii_Euxarido = ascii_Observadora = ascii_Gato = ascii_Esquecido = ascii_devorado = ""
    # ascii_anjo will be handled by the GIF loader
    ascii_SHC = ""


class AngelEngineGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Angel Engine")
        self.fullscreen = True
        self.root.attributes('-fullscreen', self.fullscreen)
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton",
                        font=("JetBrains Mono", 12, "bold"),
                        padding=5,
                        width=50,
                        foreground="white",
                        background="#333",
                        borderwidth=10)
        style.map("TButton",
                  foreground=[('pressed', 'white'), ('active', 'white')],
                  background=[('pressed', '#555'), ('active', '#555')])
        self.texto_principal = tk.Text(
            root, wrap="word", bg="black", fg="white", font=("Courier", 11), insertbackground="white" # Added insertbackground
        )
        self.texto_principal.pack(expand=True, fill=tk.BOTH)
        self.botoes_frame = tk.Frame(root, bg="black")
        self.botoes_frame.pack(fill=tk.X)

        self.item_escolhido = None

        # GIF animation attributes
        self.gif_frames = []
        self.gif_label = None
        self.current_gif_frame_index = 0
        self.gif_animation_delay = 100  # ms, default, will be updated from GIF
        self._gif_animation_job = None # To store the 'after' job ID

        # Path to your animated GIF
        self.anjo_gif_path = os.path.join(script_dir, 'Imagens', 'anjo_animado.gif')
        self.gato_gif_path = os.path.join(script_dir, 'Imagens', 'gato.gif')
        self.exibir_titulo()


    def limpar_interface(self):
        self.texto_principal.config(state=tk.NORMAL) # Ensure text widget is editable
        self.texto_principal.delete(1.0, tk.END)
        for widget in self.botoes_frame.winfo_children():
            widget.destroy()

        # Stop and remove existing GIF animation
        if self._gif_animation_job:
            self.root.after_cancel(self._gif_animation_job)
            self._gif_animation_job = None
        if self.gif_label:
            self.gif_label.destroy()
            self.gif_label = None
        self.gif_frames = []
        self.current_gif_frame_index = 0

    def _load_gif_frames(self, gif_path):
        """Loads frames from a GIF file."""
        try:
            gif = Image.open(gif_path)
            self.gif_frames = []
            self.gif_animation_delay = gif.info.get('duration', 100) # Get duration or default
            for i in range(gif.n_frames):
                gif.seek(i)
                frame_image = gif.convert('RGBA')
                self.gif_frames.append(ImageTk.PhotoImage(frame_image))
            print(f"Loaded {len(self.gif_frames)} frames from {gif_path} with delay {self.gif_animation_delay}ms.")
            return True
        except FileNotFoundError:
            print(f"Erro: Arquivo GIF não encontrado em {gif_path}")
            self.escrever_ascii(f"[GIF '{os.path.basename(gif_path)}' não encontrado]")
            return False
        except Exception as e:
            print(f"Erro ao carregar GIF {gif_path}: {e}")
            self.escrever_ascii(f"[Erro ao carregar GIF '{os.path.basename(gif_path)}']")
            return False

    def _animate_gif(self):
        """Animates the loaded GIF frames."""
        if not self.gif_frames or not self.gif_label or not self.gif_label.winfo_exists():
            return # Stop animation if label is gone or no frames

        frame = self.gif_frames[self.current_gif_frame_index]
        self.gif_label.configure(image=frame)
        self.current_gif_frame_index = (self.current_gif_frame_index + 1) % len(self.gif_frames)
        self._gif_animation_job = self.root.after(self.gif_animation_delay, self._animate_gif)

    def display_animated_gif(self, gif_path):
        """Displays an animated GIF in the text widget."""
        self.texto_principal.config(state=tk.NORMAL)
        if self._load_gif_frames(gif_path):
            if self.gif_frames:
                self.gif_label = tk.Label(self.texto_principal, bd=0, bg=self.texto_principal.cget("bg"))
                self.gif_label.image = self.gif_frames[0] # Keep a reference
                self.gif_label.configure(image=self.gif_frames[0])

                self.texto_principal.window_create(tk.END, window=self.gif_label)
                self.texto_principal.insert(tk.END, "\n") # Add a newline after the GIF
                self.texto_principal.see(tk.END)
                self.current_gif_frame_index = 0
                self._animate_gif() # Start the animation
        self.texto_principal.config(state=tk.DISABLED)

    # NOVO MÉTODO ADICIONADO
    def display_static_gif(self, gif_path):
        """Displays the first frame of a GIF statically in the text widget."""
        self.texto_principal.config(state=tk.NORMAL) # Ensure text widget is editable for window_create
        if self._load_gif_frames(gif_path): # This loads all frames
            if self.gif_frames:
                # Create a label for the GIF if it doesn't exist
                self.gif_label = tk.Label(self.texto_principal, bd=0, bg=self.texto_principal.cget("bg"))
                self.gif_label.image = self.gif_frames[0] # Keep a reference
                self.gif_label.configure(image=self.gif_frames[0])

                # Embed the label into the text widget
                self.texto_principal.window_create(tk.END, window=self.gif_label)
                self.texto_principal.insert(tk.END, "\n") # Add a newline after the GIF
                self.texto_principal.see(tk.END)
                self.current_gif_frame_index = 0 # Set to first frame
                # Crucially, DO NOT CALL self._animate_gif() here
        self.texto_principal.config(state=tk.DISABLED) # Make text widget read-only

    def alternar_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)

    def escrever_ascii(self, texto):
        self.texto_principal.config(state=tk.NORMAL)
        if texto:
            self.texto_principal.insert(tk.END, texto + "\n")
            self.texto_principal.see(tk.END)
        self.texto_principal.config(state=tk.DISABLED)


    def exibir_titulo(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_titulo)
        self.adicionar_botao("Iniciar Experiência", self.introducao)
        self.adicionar_botao("Sair do jogo", self.root.destroy)
        tocar_musica("introducao")

    def escrever(self, texto):
        self.texto_principal.config(state=tk.NORMAL)
        if texto:
            self.texto_principal.insert(tk.END, texto + "\n")
            self.texto_principal.see(tk.END)
        self.texto_principal.config(state=tk.DISABLED)


    def adicionar_botao(self, texto, comando):
        def comando_com_som():
            play_click_sound()
            comando()
        btn = ttk.Button(self.botoes_frame, text=texto, command=comando_com_som)
        btn.pack(pady=5, padx=10, fill='x')

    def adicionar_botao_lado(self, texto, comando):
        def comando_com_som():
            play_click_sound()
            comando()
        btn = ttk.Button(self.botoes_frame, text=texto, command=comando_com_som)
        btn.pack(side="left", padx=5, pady=5)

    def introducao(self):
        self.limpar_interface()
        self.escrever(
            """Você se encontra deitado em sua cama. A suave luz da lua atravessa a janela e repousa delicadamente sobre um canto do colchão.
Seus olhos pesam, vencidos pelo cansaço de um longo dia de trabalho. O silêncio da noite te envolve, e, aos poucos, o sono começa a te levar."""
        )
        self.adicionar_botao("Dormir", self.conversa_anjo)

    def conversa_anjo(self):
        self.limpar_interface()
        self.display_animated_gif(self.anjo_gif_path)
        self.escrever(
            """*(?????)*
— "Dizem que os anjos descem à Terra para resgatar os pecadores.
Em momentos de desespero, as pessoas rezam, pedem, imploram por uma salvação divina.
Mas o que acontece quando a sede por poder se torna mais forte que a fé na redenção?
EU sei a resposta. Encontre-me... e descubra a verdade." —"""
        )
        self.adicionar_botao("Seguir seus instintos curiosos", self.caminho1)
        self.adicionar_botao("Se manter na sombra do desconhecido", self.caminho2)
        self.adicionar_botao('vai filha da puta', self.cu)

    def cu(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_Gato)
        self.escrever("PENISPENISPENISPENIS KARALHOOOOOOOOOOOOOOOOOOOOOOOOOOO")

    def caminho1(self):
        self.limpar_interface()
        self.display_animated_gif(self.anjo_gif_path) # O anjo aparece animado inicialmente
        self.adicionar_botao("O que você quer de mim?", lambda: self.mensagem("Me ajude, Me ajude, Me ajude, e sua recompensa será virtuosa", self.caminho1))
        self.adicionar_botao("Quem é você?", lambda: self.mensagem("Eu já fui a última esperança, desci dos céus para ajudar a todos, livrá-los de seus pecados", self.caminho1))
        
        # LINHA MODIFICADA AQUI
        self.adicionar_botao("Por que não me fala agora?", lambda: self.mensagem("... *a figura não responde, um silêncio mortal toma conta da sua mente...*", self.caminho1, animar_figura_principal=False))
        
        self.adicionar_botao("Aonde devo ir?", self.tutorial_angel_engine)

    def tutorial_angel_engine(self):
        self.limpar_interface()
        self.escrever(
            """*A figura parece sorrir, mesmo com o rosto completamente desfigurado.*
- Tutorial para encontrar a Angel Engine:
Etapa Um: Viaje até a Terra Sagrada.
Etapa Dois: Procure, no terreno desolado, pelos grandes espinhos.
Etapa Três: Encontre meu sarcófago.
Etapa Quatro: Olhe para mim. Olhe para mim. Olhe para mim... e liberte-me.
Após alguns segundos de silêncio, você sente seu corpo sendo arrancado do sonho à força."""
        )
        self.adicionar_botao("Acordar", self.acordar)

    def acordar(self):
        self.limpar_interface()
        self.escrever(
            """Ao acordar, o som do despertador invade seus sentidos por alguns segundos.
Uma estranha sensação de que cada movimento seu está sendo julgado te afoga. Você se levanta, exausto, ainda preso às imagens da noite passada"""
        )
        self.adicionar_botao("Sair de casa", self.Sair_de_Casa)
        tocar_musica("acordar")

    def Sair_de_Casa(self):
        self.limpar_interface()
        self.escrever(
            """Fora de casa, o mundo te recebe do jeito que ele se tornou, o céu escuro coberto pela fumaças das Fábricas que Nunca Param, as ruas lotadas de lixo e de corpos de "Indignos", pessoas que os religiosos achavam ser pecadores.
Fechando a porta de casa, seu caminho será como nos outros dias, desafiador, mas isso não importa mais.
Nunca importou."""
        )
        self.adicionar_botao('Seguir o caminho indicado', self.terra_sagrada)
        self.adicionar_botao('Esquecer de tudo isso e ir trabalhar', self.ir_trabalhar)

    def terra_sagrada(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_terra)
        self.escrever(
            """Você caminha por dias, o cansaço te consome ao longo do caminho, porém de longe você vê, longos empinhos que saem do chão cobrem uma longa paisagem desértica
Finalmente chegando na Terra Sagrada. Deseja descansar?"""
        )
        self.adicionar_botao("Descansar", self.sonho)
        self.adicionar_botao("Continuar a caminhar", self.caminho_cansado)
        tocar_musica("terra_sagrada")

    def caminho_cansado(self):
        self.limpar_interface()
        self.escrever(
            """Seguindo seu rumo, o cansaço torna seus passos mais pesados, como se seus ossos fossem feitos de pedra e o mundo estivesse empurrando você de volta. O chão seco da Terra Sagrada range sob seus pés, coberto por espinhos negros que se erguem como nervuras de um corpo moribundo.
Eles não se movem. Eles não têm vida. Você repete isso mentalmente. Mas, a cada passo, você jura que um ou dois estão mais próximos — como se crescessem atrás de você.
Ao longe, é possível ver uma estrutura impossível, erguida de maneira que desafia as leis da física, guardando a única esperança da humanidade: a Máquina de Anjos"""
        )
        self.adicionar_botao('Seguir o caminho até a Máquina de anjos', self.caminho_cansado2)
        self.adicionar_botao('Procurar um lugar para descançar', self.local_descanco)

    def caminho_cansado2(self):
        self.limpar_interface()
        self.escrever(
            """Você continuar a caminhar em direção a máquina de anjos, desesperado para cumprir a sua missão, a cada passo dado torna seus movimentos mais atrapalhados.
O sol lentamente começa a cair, e a escuridão vai tomando conta, você começa a ter dificuldade de enchergar a direção de onde está indo.
A medida que se avança em direção a Máquina de Anjos, você pode ver ao lado uma grande cratera, onde você consegue observar, no centro dela, uma criatura de joelhos rezando."""
        )
        self.adicionar_botao('Continuar a caminhar', self.observadora)
        self.adicionar_botao('Descançar', self.local_descanco)

    def local_descanco(self):
        self.limpar_interface()
        self.escrever('Parando completamente seus movimentos, seu corpo dormente implora por um descanço, olhando ao redor, procurando um local para poder dormir, você observa...')
        self.adicionar_botao('Cratera.', self.cratera)
        self.adicionar_botao('Espinhos Negros', self.espinhos)
        self.adicionar_botao('Caverna', self.caverna)
    
    def cratera(self):
        self.limpar_interface()
        self.escrever('No meio dessas terras, você encontra uma enorme cratera, incrivelmente existe um caminho onde você pode descer. Adentrado a cratera, procurnado um local onde poça se sentar e descansar, você escuta grunidos estranhos vindos do centro dela.' \
        'A escuridão não deixa você distingir oque poderia ser esse barulho adentro da cratera')
        self.adicionar_botao('Continuar olhando', self.olhando_esquecido)

    def espinhos(self): 
        self.limpar_interface()
        self.escrever("Você se aproxima dos espinhos negros. Eles parecem emanar uma frieza sutil. Não parece o lugar mais confortável, mas é uma opção.")
        self.adicionar_botao("Descansar aqui mesmo", lambda: self.escrever("Você se acomoda desconfortavelmente entre os espinhos. O sono é agitado.")) # Simples lambda para mensagem direta
        self.adicionar_botao("Procurar outro lugar", self.local_descanco)


    def caverna(self): 
        self.limpar_interface()
        self.escrever("Você encontra a entrada escura de uma caverna. Um ar úmido e frio sopra de dentro.")
        self.adicionar_botao("Entrar e descansar", lambda: self.escrever("A caverna é escura e silenciosa. Você encontra um canto e adormece.")) # Simples lambda para mensagem direta
        self.adicionar_botao("Procurar outro lugar", self.local_descanco)


    def olhando_esquecido(self):
        self.limpar_interface()
        self.escrever('Você continua parado, curiosos para saber quem foi o ser que prenunciou esses sons, derrepente os sons são interrompidos e o silencio toma conta do local.')
        self.adicionar_botao('Sair correndo', self.fim_devorado)
        self.adicionar_botao('Continuar parado', self.fim_devorado)
    
    def fim_devorado(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_Esquecido)
        self.escrever_ascii(ascii_devorado)
        self.escrever('Antes que você possa pensar em agir, a figura te agarra, revelando sua força colossal enquanto te arrebenta a meio e come uma de suas metades...')
        self.adicionar_botao("Voltar ao menu", self.exibir_titulo)
        

    def observadora(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_Observadora)
        self.escrever(
            """Ignorando o ambiente se escurecendo, você continua a caminhar em direção a Máquina de anjos, o cansaço quase vence do seu corpo, quando você finalmente se encontra cara a cara com as grandes portas que bloqueiam a passagem para entrar na Máquina de anjos.
Você começa a procurar por uma maneira de entrar, quando derepente de tráz da Máquina de Anjos, você uma figura surgindo, ciculando a estrutura que a mantém presa por uma corrente, porém isso não há impede de perceber a sua presença..."""
        )
        self.adicionar_botao('Sair correndo', self.correr)
        self.adicionar_botao('Fechar os olhos e tapar os ouvidos', self.se_proteger)

    def correr(self):
        self.limpar_interface()
        self.escrever(
            """Se virando rápidamente antes que a criatura possa abrir seus olhos, Você junta forças sobrehumanas e sai correndo. A sensação de estar sendo perseguido te acompanha até conseguir se esconder em um espinhos próximo da Máquina de anjos.
Hiperventilando, você se escora em um dos espinhos. Quando você olha de volta para a criatura..."""
        )
        self.adicionar_botao('- Ela não....estava ali?', self.fim_observadora)

    def se_proteger(self):
        self.limpar_interface()
        self.escrever('Você cobre suas orelhas e fecha seus olhos da melhor maneira que pode, seus batimentos acelerados é a unica coisa que você escuta.')
        self.adicionar_botao('Abrir os olhos', self.fim_observadora2)
        self.adicionar_botao('Manter eles fechados', lambda: self.mensagem_se_proteger('Mentendo suas orelhas e olhos fechados, seus batimentos acelerados é a unica coisa que você escuta.'))

    def mensagem_se_proteger(self, texto):
        self.limpar_interface() 
        self.escrever(texto)
        # Re-adicionar os botões para manter a interação
        self.adicionar_botao('Abrir os olhos', self.fim_observadora2)
        self.adicionar_botao('Manter eles fechados', lambda: self.mensagem_se_proteger('Você continua com os olhos e ouvidos fechados. O medo cresce.'))


    def fim_observadora(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_SHC)
        self.escrever("Quando você fala isso é agarrado imediatamente pela criatura, abrindo um grande sorriso enquanto seus grandes olhos cruzam com os seus, fazendo suas pupilas fritarem em uma dor insuportável que se espalha pelo seu corpo inteiro...")
        self.adicionar_botao("Voltar ao menu", self.exibir_titulo)

    def fim_observadora2(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_SHC)
        self.escrever('Você abre seus olhos, na esperança que a criatura tenha sumido, apenas para dar de cara com grandes olhos que cruzam com os seus, fazendo suas pupilas fritarem em uma dor insuportável que se espalha pelo seu corpo inteiro... ')
        self.adicionar_botao("Voltar ao menu", self.exibir_titulo)

    def sonho(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_sonho)
        self.escrever_ascii(ascii_demon)
        self.escrever(
            """*(O Anjo)*
Eu te sinto, você está no caminho certo...
*Desta vez, você é agraciado pela visão da figura: cabelos loiros, sorriso gentil, empalada por cabos.*
Vamos, me pergunte o que te incomoda."""
        )
        self.adicionar_botao('O que é você?', lambda: self.mensagem("Eu já fui um salvador, um ser divino a serviço do senhor, fui enviado sabendo que VOCÊS rezaram e aceitaram seus pecados.", self.sonho))
        self.adicionar_botao('Oque vai ser a minha recompensa? Se for pouco eu nem vou', self.recompensa)
        self.adicionar_botao("Por que precisa da minha ajuda?", lambda: self.mensagem("... * a figura nâo responde, um silêncio toma conta da sua mente, você decide falar algo antes que ela te sufoque pela pressão", self.sonho))
        self.adicionar_botao("Onde encontro a máquina de anjos?", self.caminho_maquina_anjos)

    def recompensa(self):
        self.limpar_interface()
        self.escrever("Então, no fim você vai querer uma recompensa?")
        self.adicionar_botao("1 - Óbvio, você acha que faço isso de graça?", self.fim_egoismo)
        self.adicionar_botao("2 - Você me prometeu uma antes de vir", lambda: self.mensagem_com_arte("A figura parece entender e sorri levemente.", self.sonho, ascii_demon))

    def mensagem_com_arte(self, texto, proximo_estado, arte_ascii=None, gif_path=None):
        self.limpar_interface()
        if arte_ascii:
            self.escrever_ascii(arte_ascii)
        if gif_path: # Se for usar GIF aqui, decidir se animado ou estático
            self.display_animated_gif(gif_path) # Ou display_static_gif(gif_path)
        self.escrever(texto)
        self.adicionar_botao("Voltar", proximo_estado)


    def fim_egoismo(self):
        self.limpar_interface()
        self.escrever(
            """A figura parece descepcionada, em um movimento ela te agarra, ficando frente a frente com sua persona do sonho
- Não é a toa que seu mundo se encontra nesse estado, seus pensamentos em adquirir poder sobrepõem totalmente sua fé, sua humanidade é corrupta e pagãos não serão perdoados, não mais.
Você sente uma onda de pressão, onde suas memórias vão sendo lentamente apagadas, destruídas, consumidas, enquanto a criatura te encara com um sorriso gentil, sabendo que seu destino é se tornar mais um…"""
        )
        self.adicionar_botao("Esquecido", self.esquecido)

    def esquecido(self):
        self.limpar_interface()
        self.escrever_ascii(ascii_esquecido)
        self.escrever_ascii(ascii_Esquecido)
        self.adicionar_botao("Voltar ao menu", self.exibir_titulo)

    # MÉTODO MENSAGEM MODIFICADO
    def mensagem(self, texto, proximo_estado, animar_figura_principal=True): # Adicionado animar_figura_principal
        self.limpar_interface()

        # Reexibir a figura principal (anjo GIF) se o próximo estado for um que a utilize
        # e de acordo com o parâmetro animar_figura_principal.
        # A lógica original em 'mensagem' já exibia o anjo_gif_path para os estados
        # caminho1 e sonho ao retornar para eles.
        if proximo_estado == self.caminho1 or proximo_estado == self.sonho:
            if animar_figura_principal:
                self.display_animated_gif(self.anjo_gif_path)
            else:
                self.display_static_gif(self.anjo_gif_path)
        
        self.escrever(texto)
        self.adicionar_botao("Voltar", proximo_estado)

    def caminho_maquina_anjos(self):
        self.limpar_interface()
        self.escrever(
            """- Como chegar na Máquina de Anjos:
- Passo 1: Cubra seus ouvidos, ou eles seram estourados
- Passo 2: Não deixe que os esquecidos te encontrem. Eles não acolhem os estrangeiros.
- Passo 3: Não olhe para o céu. Seus olhos, eles irão derreter.
- Ele está aqui. Cubra seus olhos. Cubra seus ouvidos. Não pare. Ele vai te pegar. Não escute. Não acredite. O enganador não pode prejudicar sua alma."""
        )
        self.adicionar_botao("Acordar", self.dia2)
        self.adicionar_botao("Voltar", self.sonho) # Ao voltar para sonho, usará o default animar_figura_principal=True para o anjo GIF

    def dia2(self):
        self.limpar_interface()
        self.escrever(
            """Ao acordar, você sente um alivio, como se tivesse dormido por dias.
Explorar as terras sagradas não é oque você pensava, com seus olhos e ouvidos tapados, a única coisa que você sente são seus paços em uma largo campo de areia, enquanto esbarra nos espinhos longos"""
        )
        self.adicionar_botao('Seguir andando', self.dia2_caminhando)

    def dia2_caminhando(self):
        self.limpar_interface()
        self.escrever(
            """Você continua tateando pela escuridão autoimposta. O ar fica mais denso.
Um cheiro metálico sutil atinge suas narinas, mesmo com os ouvidos e olhos cobertos,
a sensação de perigo é palpável."""
        )
        self.adicionar_botao('Continuar com cuidado', lambda: self.mensagem("Você avança, sentindo a textura do ambiente mudar...", self.dia2_caminhando_perto))
        self.adicionar_botao('Recuar e tentar outro caminho (Não implementado)', self.dia2)


    def dia2_caminhando_perto(self):
        self.limpar_interface()
        self.escrever("O chão sob seus pés se torna irregular. Você sente o que parecem ser degraus descendentes...")
        self.adicionar_botao("Descer os degraus (FIM DE DEMO - CAMINHO DIA 2)", self.exibir_titulo)


    def caminho2(self):
        self.limpar_interface()
        self.escrever(
            """Com seus sentidos perturbados pela presença da figura, você decide ignorar o chamado e acordar.
Ao acordar, o som do despertador inibe seus sentidos por alguns segundos. A sensação de que cada ação sua está sendo julgado te afoga, enquanto você se levanta cansado, ainda pensando sobre oque sonhou na noite passada."""
        )
        self.adicionar_botao('Sair de casa', self.Sair_de_Casa2)

    def Sair_de_Casa2(self):
        self.limpar_interface()
        self.escrever(
            """Fora de casa, o mundo te recebe do jeito que ele se tornou, o céu escuro coberto pela fumaças das Fábricas que Nunca Param, as ruas lotadas de lixo e de corpos de "Indignos", pessoas que os religiosos achavam ser pecadores.
Fechando a porta de casa, seu caminho será como nos outros dias, desafiador, mas isso não importa mais.
Nunca importou."""
        )
        self.adicionar_botao('Ir trabalhar', self.ir_trabalhar)
        self.adicionar_botao('Regredir e escutar o Anjo', self.regredir)

    def ir_trabalhar(self):
        self.limpar_interface()
        self.escrever('O vazio da cidade apertava a cada amanhecer, uma presença gelada que suplantava o trânsito e o burburinho de outrora. Agora, onde antes havia cafés e lojas de esquina, cresciam igrejas.'
        '\nNão eram templos grandiosos, mas caixas de concreto cinza, brotando como fungos malignos em cada quarteirão, seus sinos eletrônicos martelando a mesma reza monótona no ar pesado. As portas, sempre abertas, pareciam bocas famintas esperando engolir mais um.'
        'Seu trabalho de desmontar embalagens, dobrar caixas vazias, nunca foi especial. E você, de fato, se orgulha disso. '
        '\nNesse mundo onde todos parecem desesperados para pertencer, para gritar sua existência aos céus, você se vê como a sombra, o esquecido. Aquele que ninguém nota, e que, por isso, talvez seja o único a realmente enxergar.')
        self.adicionar_botao('Trabalhar normalmente', self.intervalo)
        self.adicionar_botao('Trabalhar lentamente', self.visita_chefe_irritado)
        self.adicionar_botao('Trabalhar esforçadamente', self.visita_chefe)

    def intervalo(self):
        self.limpar_interface()
        self.escrever("Em meio ao zumbido constante das máquinas e ao balé tedioso de seus colegas, você senta em sua mesa pacata e inicia sua rotina diária." \
        "\nAs horas tecem com seus movimentos tediosos, até que a sirene do intervalo quebra o silêncio com uma promessa de pausa que talvez nunca venha a ser um verdadeiro descanso.")
        self.adicionar_botao("Pegar seu almoço e ir para refeitório", self.refeitorio)

    def visita_chefe_irritado(self):
        self.limpar_interface()
        self.escrever("Seus movimentos são um peso, cada ação arrastada como se o ar fosse denso. A figura do chefe, uma sombra imponente, materializa-se ao seu lado. A voz, um rosnado baixo e irritado, corta seu raciocinio: 'Se não consegue manter o ritmo, outros conseguem. Já sabe onde é a porta.'")
        self.adicionar_botao("- Desculpe chefe ", self.trabalhador_triste)
    
    def trabalhador_triste(self):
        self.limpar_interface()
        self.escrever('Você retorna ao trabalho, tentato pegar o mesmo ritmo de seus colegas, até que a sirene do intervalo quebra o silêncio.')
        self.adicionar_botao("Pegar seu almoço e ir para refeitório", self.refeitorio)

    def visita_chefe(self):
        self.limpar_interface()
        self.escrever('Cada movimento é um esforço, cada tarefa, um elo perfeito na corrente da produção.' \
        '\nVocê se empurra, forçando uma eficiência quase desumana. Seu chefe o observa, no seu sorriso, uma promessa fugaz de algo soa simulado. "Muito bom. Seu trabalho está impressionante.')
        self.adicionar_botao("Agradecer", self.trabalhador_cansado)
    
    def trabalhador_cansado(self):
        self.limpar_interface()
        self.escrever("Você agradeçe seu chefe, enquanto ele sai de sua mesa pacata, a sirene do intervalo quebra o silêncio.")
        self.adicionar_botao("Pegar seu almoço e ir para sala de descanço", self.refeitorio)

    def refeitorio(self):
        self.limpar_interface()
        self.escrever('Você se dirigiu à sala de descanso, o cheiro de comida requentada e suor impregnado no ar. Ao se sentar, a tela da televisão no canto brilhou com as cores frias de um anúncio governamental. Mensagens sobre "ordem" e "progresso" piscavam, ruído branco que você sempre ignorou. ' \
        'Mas desta vez, algo era diferente. Seus colegas, geralmente absortos em seus próprios mundos minúsculos, tinham os olhos fixos na tela. Havia uma tensão palpável, uma apreensão silenciosa que os unia.')

        self.adicionar_botao('Prestar atenção na transmissão', self.anuncio)
        self.adicionar_botao('Terminar seu almoço e voltar a trabalhar', self.fim_trabalhador)
    
    def anuncio(self):
        self.limpar_interface()
        self.escrever('-Boa noite, senhoras e senhores. A voz do presidente preencheu o ar, rouca, mas firme. Seus olhos se ergueram para a tela, onde o rosto dele, vincado pela tensão, preenchia o enquadramento.' \
        '\nA imagem era de uma gravidade absoluta, quase pétrea. O único som a perfurar o silêncio atordoado da sala era o chiado intermitente da transmissão, uma falha que parecia amplificar a precariedade daquele momento.'
        '\n-Estou diante de vocês neste dia como homem, marido, pai, como seu Presidente, mas o mais importante, como cidadão deste país.'
        '\n-Não vou adoçar nossa situação atual; Estamos à beira da guerra.')
    
    def fim_trabalhador(self):
        self.limpar_interface()
        self.escrever('O gosto metálico da comida processada ainda persistia em sua boca enquanto você se levantava, empurrando a cadeira de plástico que rangia em protesto. Você se viu andando para o seu posto, de maneira quase automática, os murmúrios sobre o anúncio governamental já se dissolvendo na indiferença que sempre te envolveu.' \
        '\nEm sua mesa, a pilha de caixas o aguardava. Uma montanha de papelão, idêntica às milhares de outras que você já havia manipulado. Seus olhos se fixaram nelas, um peso esmagador se assentou em seu peito. O fardo de todos os anos inúteis que você havia entregado a este lugar, a essa rotina.' \
        '\nCada caixa dobrada, cada pacote selado, somava-se a uma pilha invisível de dias e horas desperdiçadas, de sonhos esquecidos, de uma vida que nunca realmente começou, porém agora é tarde demais para tentar fazer algo. Com suas mãos sujas de culpa, você...')

        self.adicionar_botao('volta a trabalhar', lambda: self.escrever_ascii(ascii_trabalhador),self.adicionar_botao("Voltar ao menu", self.exibir_titulo))   #parei aqui, dar uma revisada pq não ta legal


    def regredir(self):
        self.limpar_interface()
        self.escrever('Você decide ajudar o anjo, se entregrando a aquela pressão estranha que ele fazia...')
        self.adicionar_botao('Ouvir oque ele tem pra dizer', self.caminho1)

if __name__ == "__main__":
    try:
        from PIL import Image, ImageTk
    except ImportError:
        print("Pillow (PIL) não está instalado. Para exibir GIFs, instale com: pip install Pillow")
        pass

    root = tk.Tk()
    app = AngelEngineGUI(root)
    root.mainloop()